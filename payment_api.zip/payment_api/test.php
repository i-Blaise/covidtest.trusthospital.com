<?php
$date = new \DateTime();
$dateTime = $date->format('YmdHisv');
print($dateTime);