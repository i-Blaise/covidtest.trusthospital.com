<?php

define("PAYFLUID_BASE_URL", "https://payfluid-api.herokuapp.com/payfluid/ext/api");
define("PAYFLUID_API_ID", "04040405");
define("PAYFLUID_API_KEY", "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAI8LN/AC3XOz23O7v/de/jbYFQYrbeFqQVaIYpFRIR+YSCWfHlcl3PNKy7Vniq+rWG8KPN8uw2RUU/1qvoZP3xsCAwEAAQ==");
define("PAYFLUID_LOGIN_PARAMETER", "781e5e245d69b566979b86e28d23f2c7");
define("PAYFLUID_AUTO_VERIFY", TRUE);
?>

