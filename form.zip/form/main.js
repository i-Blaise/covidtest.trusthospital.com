
jQuery(document).ready(function(){
    jQuery(".hideshow").click(function(){
        jQuery('.cardstack__main').toggleClass("reveal");
    });
});